﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Star : MonoBehaviour {

    // Tähden nopeus
    public float starSpeed;

    //Yhteys tähden fysiikkamoottoriin
    private Rigidbody2D rb2d;

    //Erikoistehostetta varten muuttuja
    public GameObject starEffect;


	// Use this for initialization
	void Start () { 

        //Otetaan yhteys fysiikkamoottoriin
        rb2d = GetComponent<Rigidbody2D>(); 

        
	}
	
	// Update is called once per frame
	void Update () {

        //Tähden nopeus X-akselin suunnassa
        rb2d.velocity = new Vector2(starSpeed * transform.localScale.x, 0);
		
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
		//Osuiko tähti pelihahmoon1?
		if (collision.CompareTag("Player1")) {
			//Tähti osuu pelihahmoon1, joten vähennetään siltä 1 elämä
			FindObjectOfType<GameManager>().HurtP1();
		}
		//Osuiko tähti pelihahmoon2?
		if (collision.CompareTag("Player2proto")) {
			//Tähti osuu pelihahmoon2, joten vähennetään siltä 1 elämä
			FindObjectOfType<GameManager>().HurtP2();
		}

        //Tähden törmäysefekti: Luodaan tähden törmäysefekti ja tuhotaan se törmäyksen jälkeen
        Instantiate(starEffect, transform.position, transform.rotation);
        Destroy(gameObject);
    }


}
