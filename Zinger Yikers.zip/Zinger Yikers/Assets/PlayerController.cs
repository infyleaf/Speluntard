﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    //Pelihahmon nopeus x-akselin suunnassa
    public float movespeed;
    public float jumpforce;


    //näppäin muuttuja
    public KeyCode left;
    public KeyCode right;
    public KeyCode jump;
    public KeyCode throwStar;

    private Rigidbody2D rb2d;
    //Yhteys fysiikkamoottoriin

    //Hyppyyn liittyvät muuttujat
    public Transform groundCheckpoint;
    public float groundCheckRadius;
    public LayerMask whatIsGround;
    public bool isGround;




    // Animaattori
    private Animator anim;

    //Heittämiseen liittyvät muuttujat
    public Transform throwPoint; // heittopiste
    public GameObject star; //se mitä heitetään


    // Jos isGround = true, niin ollaan maassa
    // Use this for initialization
    void Start()
    {
        // Yhteys pelihahmoon fysiikkamoottoriin
        rb2d = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {

        //Pelihahmon liike

        if (Input.GetKey(left))
        {
            //Jos true liikutaan vasemmalle
            rb2d.velocity = new Vector2(-movespeed, rb2d.velocity.y);
        }
        else if (Input.GetKey(right))
        {   //Jos true liikutaan oikealle
            rb2d.velocity = new Vector2(+movespeed, rb2d.velocity.y);
        }


        else
        {
            //pelihahmo ei liiku
            rb2d.velocity = new Vector2(0, rb2d.velocity.y);
        }



        //Pelihahmon hyppy
        if (Input.GetKeyDown(jump) && isGround)
        {
            // Pelihahmo hyppää jos ollaan maassa ja painettu W
            rb2d.velocity = new Vector2(rb2d.velocity.x, jumpforce);
        }

        // Tähden heitto

        if (Input.GetKeyDown(throwStar))
        {
            //Heitetään tähti
            // Instantiate(star, throwPoint.position, throwPoint.rotation);
            print("Testi");
         GameObject starClone = (GameObject)Instantiate(star, throwPoint.position, throwPoint.rotation);
            starClone.transform.localScale = transform.localScale;

            //Heittoanimaatio
            anim.SetTrigger("Throw");


        }




        //Maatarkistus eli ollaanko maassa vai ilmassa
        isGround = Physics2D.OverlapCircle(groundCheckpoint.position, groundCheckRadius, whatIsGround);
        print("Maassa ; " + isGround);




		//Pelihahmon suunnanmuutos

        if(rb2d.velocity.x < 0)
        {
            transform.localScale = new Vector3(-1, 1, 1);
        } else if (rb2d.velocity.x > 0)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }

        // Kävely ja hyppy animaatiot

        anim.SetFloat("Speed", Mathf.Abs(rb2d.velocity.x));
        anim.SetBool("Grounded", isGround);
    








         

    }
}

