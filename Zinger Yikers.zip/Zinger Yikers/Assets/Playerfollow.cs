﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playerfollow : MonoBehaviour {

	public Transform player1;
	public Vector3 offset;
	void Update () 
	{
		transform.position = new Vector3 (player1.position.x + offset.x, player1.position.y + offset.y, offset.z); // Camera follows the player with specified offset position
	}




	// Use this for initialization
	void Start () {
		offset = transform.position - player1.transform.position;
	}
	
	// Update is called once per frame
}
