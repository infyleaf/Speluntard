﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

	// Use this for initialization

		public GameObject player1;
		public GameObject player2;

		//Pelihahmon kokonaiselämä
	public int P1Life;
	public int P2Life;


	//GameOver paneelit
	public GameObject p1Wins;
	public GameObject p2Wins;

	//Elämäpiste-taulukko. Taulukkoon tallennetaan kuvat, jotka mallintavat pelihahmon elämää.
	public GameObject[] p1Sticks;
	public GameObject[] p2Sticks;

	//Lipun suoja colliderit
	public GameObject FlagBlueCollider;
	public GameObject FlagPurpCollider;




	
	// Update is called once per frame
	void Update () {
		//Onko pelihahmo 1 elossa?
		if(P1Life <=0) {			
			//Pelihahmo 1 ei ole elossa eli pelihahmo 2 voitti
			player1.SetActive(false);
			p2Wins.SetActive (true);

			//Aktivoi pelihahmo1 lipun stoppari, jotta lipun voi napata
			FlagBlueCollider.SetActive(false);
	}

		//Onko pelihahmo 2 elossa? 
		if(P2Life <= 0) {
			//Pelihahmo 2 ei ole elossa eli pelihahmo 1 voitti
			player2.SetActive(false);
			p1Wins.SetActive (true);
			//Aktivoi pelihahmo2 lipun stoppari, jotta lipun voi napata
			FlagPurpCollider.SetActive (false);
}

	}

	//Aiheutetaan vahinkoa pelihahmo1
	public void HurtP1()
	{
		// Vähennetään 1 elämä
		P1Life -= 1;
		for (int i = 0; i < p1Sticks.Length; i++) {
			if (P1Life > i) {
				p1Sticks [i].SetActive (true);
			} else {
				//Kuva poistetaan
				p1Sticks [i].SetActive (false);
				
			}
		}
	}

	public void HurtP2()
	{
		// Vähennetään 1 elämä
		P2Life -= 1;
		for (int i = 0; i < p2Sticks.Length; i++) {
			if (P2Life > i) {
				p2Sticks [i].SetActive (true);
			} else {
				//Kuva poistetaan
				p2Sticks [i].SetActive (false);

			}
		}
	}


}