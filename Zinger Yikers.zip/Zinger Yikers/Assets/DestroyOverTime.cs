﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOverTime : MonoBehaviour {

    // GameObjectin Elinikä

    public float lifetime;
	
	// Update is called once per frame
	void Update () {

        //Vähennetään elinajasta deltaTime
        lifetime -= Time.deltaTime;
        // Onko elinikä kulunut loppuun?
        if(lifetime < 0)
        {
            //On, joten tuhotaan kyseinen GameObjecti
            Destroy(gameObject);
        }
	}
}
