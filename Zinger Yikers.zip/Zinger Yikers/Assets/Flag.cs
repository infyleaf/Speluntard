﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Flag : MonoBehaviour {


	public string levelName;

	private void OnTriggerEnter2D(Collider2D collision)
	{
		//Osuiko pelihahmo 1 lippuun?
		if (collision.CompareTag ("Player1"))
		{
			//Pelihahmo 1 osui lippuun, joten poistetaan se ja 
			// sirrytään seuraavalle tasolle
			Destroy(gameObject);
			NextLevel (levelName);
		}
			
		//Osuiko pelihahmo 2 lippuun?
		if (collision.CompareTag ("Player2proto"))
		{
			//Pelihahmo 2 osui lippuun, joten poistetaan se ja 
			// sirrytään seuraavalle tasolle
			Destroy(gameObject);
			NextLevel (levelName);
		}

	}
	public void NextLevel (string levelName)
	{
		// Siirrytään toiselle tasolle
		SceneManager.LoadScene(levelName);

	}



}
