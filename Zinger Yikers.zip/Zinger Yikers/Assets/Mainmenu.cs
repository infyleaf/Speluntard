﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Mainmenu : MonoBehaviour {

	public string startLevel;

	public void NewGame()
	{
		//Käynnistää uuden pelin
		SceneManager.LoadScene (startLevel);
	}

	public void QuitGame()
	{
		//Lopettaa pelin
		Application.Quit();
	}

		
}
